<footer class="footer">
      <div class="container">
      <div class="row align-items-center">
      <div class="col">
        <p align="center"><font color= "000000">You In Game - 2023</font></p>
      </div>
      </div>
      <p align="center"><img src="<?php bloginfo('template_directory') ?>/images/media.png" height="30"></p>
      </div>
    </footer>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  <script src="<?php bloginfo('template_directory') ?>/Bootstrap/js/bootstrap.min.js"></script>
</body>
</html>