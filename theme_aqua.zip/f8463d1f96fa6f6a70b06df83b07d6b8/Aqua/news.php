<?php get_header(); ?>

<section class = "main">
      <div class='line'></div>
      <div style="margin: 50px 0px 0px 0px"></div>
      <div class="container">
        <div>
          <p align="center" style="font-size:40px"><font color= "FFFFFF">Новости от <font color= "F9EF06">You<br> In Game</font></p>
        </div>
        <div style="margin: 130px 0px 0px 380px"></div>
        <div>
          <p align="center" style="font-size:20px"><font color= "FFFFFF">У нас ты можешь быть уверен:</font></p>
            <div class='line_text'style="margin: 0px 0px 0px 460px"></div>
        </div>
        <div>
          <p align="center" style="font-size:20px"><font color= "FFFFFF">В <cпроверенной</font> информации  <br>
            В <font color= "F9EF06">граммотных</font> блогерах <br>
            В <font color= "F9EF06">компетентных</font> и <font color= "F9EF06">отзывчивых</font> администраторах</font></p>
        </div>
        <div style="margin: 50px 0px 0px 0px">
          <p align="center" style="font-size:20px"><font color= "FFFFFF">Каждую неделю редакторы сайта <font color= "F9EF06">You in Game</font> находят и размещают самые актуальные и интересные новости</font> </p>
        </div>
      </div>
    </section>

    <section class = "main">
      <div class='line'></div>
      <div class="container">
        <div style="margin: 50px 0px 0px 0px">
          <p align="center" style="font-size:30px"><font color= "FFFFFF"><font color= "F9EF06">Новости</font> мира киберспорта и игр</font></p>
      <div class="container text-center" style="margin: 50px 0px 0px 0px">
        <div class="row align-items-center">
          <div class="col">
            <p><img src="<?php bloginfo('template_directory') ?>/images/ФИО1.png" width="290" height="220"></p>
          </div>
          <div class="col">
            <p><font color= "FFFFFF">ОтзывvОтзывОтзывОтзывОтзывОтзывОтзывОтзывОтзыв
              <br>ОтзывvОтзывОтзывОтзывОтзывОтзывОтзывОтзывОтзыв
              <br>ОтзывvОтзывОтзывОтзывОтзывОтзывОтзывОтзывОтзыв</font></p>
          </div>
        </div>
        <div class="row align-items-center">
          <div class="col">
            <p><img src="<?php bloginfo('template_directory') ?>/images/ФИО2.png" width="290" height="220"></p>
          </div>
          <div class="col">
            <p><font color= "FFFFFF">ОтзывvОтзывОтзывОтзывОтзывОтзывОтзывОтзывОтзыв
              <br>ОтзывvОтзывОтзывОтзывОтзывОтзывОтзывОтзывОтзыв
              <br>ОтзывvОтзывОтзывОтзывОтзывОтзывОтзывОтзывОтзыв</font></p>
          </div>
        </div>
      </div>
      <div style="margin: 20px 0px 0px 0px"></div>
    </section>

    <section class = "main">
      <div class='line'></div>
      <div class="container">
        <div style="margin: 50px 0px 0px 0px">
      <div class="container" style="margin: 50px 0px 0px 0px">
        <div class="row align-items-center" style="margin: 0px 100px 0px 100px">
          <div class="col">
            <p style="font-size:30px"><font color= "F9EF06">Контакты</font></p>
          </div>
          <div class="col">
            <p style="font-size:30px"><font color= "F9EF06">Мы на карте</font></p>
          </div>
        </div>
        <div class="row align-items-center" style="margin: 0px 15px 0px 100px">
          <div class="col">
            <p><font color= "FFFFFF"><font color= "F9EF06">Адрес:</font> ул. Пушкина д. 62</font></p>
            <p><font color= "FFFFFF"><font color= "F9EF06">Телефон:</font> +8 951 235 45 45</font></p>
            <p><font color= "FFFFFF"><font color= "F9EF06">ВК:</font> vk.com/YouINGame</font></p>
            <p><font color= "FFFFFF"><font color= "F9EF06">Telegram:</font> +8 951 235 45 45</font></p>
          </div>
          <div class="col">
            <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A4abd83f7b35a94e4e6fea3ed8b2dae9b23a986534a4f44749ebe069af04e40bd&amp;width=500&amp;height=400&amp;lang=ru_RU&amp;scroll=true"></script> 
          </div>
        </div>
      </div>
      <div style="margin: 30px 0px 0px 0px"></div>
    </section>

    <?php get_footer(); ?>