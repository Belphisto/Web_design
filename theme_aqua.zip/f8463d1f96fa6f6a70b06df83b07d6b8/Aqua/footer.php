<footer class="footer">
      <div class="section-contacts">
              
    <div class="container">
      <div class="row">
        <div class="col-md-6 " id = "contacts">
          
          <img src="<?php bloginfo('template_directory') ?>/images/image 34.png" alt="Image" class="img-fluid">
        </div>
        <div class="col-md-3 offset-md-3">
          <img src="<?php bloginfo('template_directory') ?>/images/Group 17.png" alt="Image" class="img-fluid">
        </div>
        </div>
      </div>
    </div>
    </footer>
</body>
</html>